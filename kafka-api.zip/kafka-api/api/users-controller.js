const express = require("express");
var cors = require('cors')
const { Pool } = require('pg');

const router = express.Router();
router.use(cors());
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'kafka',
  password: 'password',
  port: 5432
});

//GET
router.get('/', (request, response) => {
  const query = {
    name: 'fetch-users',
    text: 'SELECT * FROM users'
  };

  pool.query(query, (error, results) => {
    if (error) {
      throw error;
    } else {
      response.status(200).json(results.rows);
    }
  });
});

//GET :id
router.get('/:id', (request, response) => {
  const id = parseInt(request.params.id, 10);
  const query = {
    name: 'fetch-user',
    text: 'SELECT * FROM users WHERE "Id" = $1',
    values: [id],
  };
  
  pool.query(query, (error, results) => {
    if (error) {
      throw error;
    } else {
      response.status(200).json(results.rows[0]);
    }
  });
});

//POST
router.post('/', (request, response) => {
  const { username } = request.body;
  const query = {
    name: 'create-user',
    text: 'INSERT INTO users("Username") VALUES ($1)',
    values: [username]
  };

  pool.query(query, (error, results) => {
    if (error) {
      throw error;
    } else {
      console.log(results);
      response.status(201).send(`User added.`);
    }
  });
});

//PUT :id
router.put('/:id', (request, response) => {
  const id = parseInt(request.params.id, 10);
  const { username } = request.body
  const query = {
    name: 'update-user',
    text: 'UPDATE users SET "Username" = $1 WHERE "Id" = $2',
    values: [username, id]
  };

  pool.query(query, (error, results) => {
      if (error) {
        throw error
      } else {
        response.status(200).send(`User with id ${id} modified.`)
      }
    }
  )
});

//DELETE
router.delete('/:id', (request, res) => {
  const id = parseInt(request.params.id, 10);
  const query = {
    name: 'delete-user',
    text: 'DELETE FROM users WHERE "Id" = $1',
    values: [id]
  };

  pool.query(query, (error, results) => {
    if (error) {
      throw error;
    } else {
      res.status(200).send(`User with id ${id} deleted.`);
    }
  });
});

module.exports = router;