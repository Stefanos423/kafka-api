// TODO:
// * Add error handling.
// * Add exception handling (eg entity not found exception).
// * Add input validation.
// * Add tests.

const express = require("express");
const bodyParser = require("body-parser");
const userRoutes = require("./api/users-controller.js");

const app = express();

// body parser set up
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// routes set up
app.use('/api/users', userRoutes);

// server port set up
const port = process.env.port || 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));